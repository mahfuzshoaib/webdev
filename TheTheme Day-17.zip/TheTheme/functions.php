<?php
    wp_enqueue_style('style-1',get_stylesheet_uri());
    wp_enqueue_style('style-bootstrap',get_template_directory_uri().'/Assets/css/bootstrap.min.css');
    wp_enqueue_script('script-name', get_template_directory_uri().'/Assets/js/bootstrap.bundle.min.js', array(), '1.0', true);

    add_theme_support('custom-logo');
    add_theme_support('post-thumbnails');
    register_nav_menus([
        'TM'=> 'Primary',
        'FM'=> 'Footer'
    ]);
    
    register_sidebar([
        'name' => 'Main Banner',
        'id' => 'mainbanner',
        'before_widget' => '',
        'after_widget' => ''
    ]);
    register_sidebar([
        'name' => 'Sidebar Image',
        'id' => 'sideimage',
        'before_widget' => '',
        'after_widget' => ''
    ]);
    register_sidebar([
        'name' => 'Sidebar Video',
        'id' => 'sidebarvideo',
        'before_widget' => '',
        'after_widget' => ''
    ]);
    register_sidebar([
        'name' => 'Footer Top Image',
        'id' => 'ftimg',
        'before_widget' => '',
        'after_widget' => ''
    ]);
    register_sidebar([
        'name' => 'Footer Bottom Image',
        'id' => 'fbimg',
        'before_widget' => '',
        'after_widget' => ''
    ]);
    register_sidebar([
        'name' => 'Notice',
        'id' => 'notice',
        'before_widget' => '',
        'after_widget' => '',
    ]);
?>