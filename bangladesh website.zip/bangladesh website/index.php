<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh</title>
    <?php wp_head();?>
</head>
<body>
    <!-- header part start -->
<header class="cont">
        <div class="row topbar">
            <div class="col-sm-6 tb_left">
                <?php dynamic_sidebar('t_left');?>
            </div>
            <div class="col-sm-6 tb_right text-end">
                <p>English</p>
            </div>
        </div> 
   <div class="row header">
        <div class="col-md-5 logo_left">
            <?php the_custom_logo();?>
        </div>
        <div class="col-md-5 logo_search">
            <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="খুঁজুন " aria-label="Search">
            <button class="" type="submit">অনুসন্ধান </button>
            </form> 
        </div>
        <div class="col-md-2 logo_left">
            ghfdth
        </div>
   </div>
</header>
<section class="cont menu">
    <div class="row">
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav">
                    <?php wp_nav_menu([
                        'menu_class' => 'navbar',
                        'theme_location' => 'PM',
                    ]);?>
                    
                </div>
                </div>
            </div>
        </nav>
    </div>
</section>
    <!-- header part end -->
    <!--  body part start -->
    <section class="section hero cont">
        <div class="row">
            <!-- slider part start -->
            <div class="col-lg-8">
                <div class="banner">
                <?php dynamic_sidebar('banner');?>
                </div>
                <div class="slider">    
                    <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php
                            $slider = new WP_Query([
                                'post_type'=>'post',
                                'category_name'=>'slider'
                            ]);
                            $x = 0; 
                            while ($slider->have_posts()) {$slider->the_post();
                                $x++;
                            ?>
                            <div class="carousel-item <?=($x==1)?'active': ''?>">
                            <?php the_post_thumbnail();?>
                            </div>
                            <?php }?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
                <!-- tab part start -->
                <div class="tab-container">
                
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Home</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Profile</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Contact</button>
                    </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                        <?php 
                            $tab = new WP_Query([
                                'post_type'=>'post',
                                'category_name'=>'tab'
                            ]);
                        ?>
                        <div class="row">
                            <?php 
                                while($tab->have_posts()){
                                    $tab->the_post();
                            ?>
                            <div class="col-lg-2">
                                <a href="#">
                                    <?php the_post_thumbnail();?>
                                    <img src="" alt="">
                                </a>
                                <?php the_title();?>
                                <p></p>
                            </div>
                            <?php }?>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">...</div>
                    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">...</div>
                    <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">...</div>
                    </div>

                </div>
                <!-- tab part end -->
                <!-- news part start -->
                <div class="news">
                    <p>উদ্যোগ</p>
                    <?php dynamic_sidebar('nl')?>
                </div>
                <!-- news part end -->
                <!-- News Banner part start -->
                <div class="n_banner">
                <?php dynamic_sidebar('nb');?>
                </div>
            <!-- News Banner part end -->
            </div>
            <!-- slider part end -->
            <div class="col-lg-4 sidebar">
                <div class="sidebar_img">
                    <?php dynamic_sidebar('sidebar_img');?>
                </div>
                <div class="sidebar-search">
                    <p>সকল বাতায়ন</p>
                    <?php dynamic_sidebar('ss')?>
                </div>
                <div class="video-1">
                   <?php dynamic_sidebar('v1');?>
                </div>
            </div>
        </div>
    </section>
    <!--  body part end --> 
    <footer class=" cont footer_main">
        <div class="ft">
            <?php dynamic_sidebar('ft_img');?>
        </div>
        <div class="row">
            <div class="col-md-7 footer_menu">
                <ul>
                    <li><a href="#">গোপনীয়তার নীতিমালা</a></li>
                    <li><a href="">ব্যবহারের শর্তাবলি</a></li>
                    <li><a href="#">ব্যবহারের শর্তাবলি</a></li>
                    <li><a href="">সাইট ম্যাপ</a></li>
                    <li><a href="#">সাইট ম্যাপ</a></li>
                </ul>
            </div>
            <div class="col-md-5"></div>
        </div>
    </footer>
   
<?php wp_footer();?> 
</body>
</html>