<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'bootstarp-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo');
add_theme_support( 'post-thumbnails');

register_nav_menus( array(
    'PM' => 'Primary' ,
    'FM'  => 'Footer',
) );

register_sidebar( array(
    'name'          => 'topbar left',
    'id'            => 't_left',
    'before_widget' => '',
    'after_widget'  => '',
) );

register_sidebar( array(
    'name'          => 'topbar right',
    'id'            => 't_right',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Banner',
    'id'            => 'banner',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Sidebar Image',
    'id'            => 'sidebar_img',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Tab 1 Section',
    'id'            => 'tab-1',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'News list',
    'id'            => 'nl',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'News Banner',
    'id'            => 'nb',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Sidebar Search',
    'id'            => 'ss',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Footrer top image',
    'id'            => 'ft_img',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Video 1',
    'id'            => 'v1',
    'before_widget' => '',
    'after_widget'  => '',
) );
?>