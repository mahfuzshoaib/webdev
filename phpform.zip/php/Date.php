<!DOCTYPE html>
<html>
<body>

<?php
echo "Today is " . date("Y/m/d") . "<br>";
echo "Today is " . date("Y.m.d") . "<br>";
echo "Today is " . date("Y-m-d") . "<br>";
echo "Today is " . date("l");


    if(date("m") == "01"){
        echo "<br>It's the January";
    }
    else{
        echo "<br>It's not January";
    }
?>
</body>
</html>
