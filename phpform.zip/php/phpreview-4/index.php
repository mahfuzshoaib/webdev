<?php
class Fruit{
    //property
    public $name;
    public $color;

    //method
    public function set_name($v){
        $this->name = $v;
    }
    public function get_name(){
        return $this->name;
    }
}

$Apple = new Fruit();
$Banana = new Fruit();

$Apple->set_name("Apple");
$Banana->set_name("Banana");

echo $Apple->get_name();
echo "<br>";
echo $Banana->get_name();

?>