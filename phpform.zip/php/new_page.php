<?php
    include "header.php";
    include "menu.php";
    include "sidebar.php";
    include "body.php";
    include "footer.php";
?>