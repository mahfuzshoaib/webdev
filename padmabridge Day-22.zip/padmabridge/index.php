<!DOCTYPE html>
<html <?php language_attributes();?>>
<head>
    <meta charset="<?php bloginfo( 'charset' )?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head();?>
</head>
<body>
    <!-- Header part start -->
    <header class="slider container-fluid">
        <div class="row">
        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
  <div class="carousel-inner">

    <?php 

        $x = 0;
            while(have_posts()){the_post();
        $x++;
    ?>
    <div class="carousel-item <?= ($x==1) ? 'active' : ''?>">
        <?php the_post_thumbnail();?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php }?>
    <!-- <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div> -->
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
        </div>
    </header>
    <!-- Header part end -->
    <!-- Logo part start -->
    <section class="container-fluid logo">
        <div class="row">
            <div class="col-sm-6 logo_left"><?php the_custom_logo();?></div>
            <div class="col-sm-6 logo_right text-end"><?php dynamic_sidebar( 'logo_right' ); ?></div>
        </div>
    </section>
    <!-- Logo part end -->
    <!-- Menu part start -->
    <section class="container-fluid menu_tp">
        <div class="row">
            <nav class="navbar navbar-expand-lg bg-light">
                <div class="container">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'TM',
                            'menu_class' => 'navbar-nav menu_item'
                        ));
                        ?>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                    </ul>
                    </div>
                </div>
            </nav>
        </div>
    </section>
    <!-- <section class="container-fluid">
    </section> -->
    <!-- Menu part end -->
    <!-- Hero part start -->
    <section class="container hero">
        <div class="row hero_title"> <?php dynamic_sidebar('h_title');?> </div>
        <div class="row hero_card">
            <div class="col-sm-4">
                <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('card_img_1');?>
                        <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <?php dynamic_sidebar('card_info_1');?>
                        <!-- <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> 
                        <a href="#" class="btn btn-primary">Go somewhere</a> -->
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('card_img_2');?>
                        <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <?php dynamic_sidebar('card_info_2');?>
                        <!-- <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> 
                        <a href="#" class="btn btn-primary">Go somewhere</a> -->
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('card_img_3');?>
                        <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <?php dynamic_sidebar('card_info_3');?>
                        <!-- <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> 
                        <a href="#" class="btn btn-primary">Go somewhere</a> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero part end -->
    <!-- Photo Part Start -->
    <section class="container photo text-center mt-5 mb-5">
        <div class="row">
            <div class="col-sm-5">
                <?php get_template_directory_uri(). '/assets/images/gallery/sb.png' ; ?>
            </div>
            <div class="col-sm-2">
                <h4>Recent Photos</h4>
                <p>Some Latest Project Pictures</p>
            </div>
            <div class="col-sm-5">
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="card" style="width: 16rem;">
                    <?php dynamic_sidebar('photoimg-1');?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <!-- <h5 class="card-title">Card title</h5> -->
                        <?php dynamic_sidebar('phototitle-1');?>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 16rem;">
                    <?php dynamic_sidebar('photoimg-2');?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <!-- <h5 class="card-title">Card title</h5> -->
                        <?php dynamic_sidebar('phototitle-2');?>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 16rem;">
                    <?php dynamic_sidebar('photoimg-3');?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <!-- <h5 class="card-title">Card title</h5> -->
                        <?php dynamic_sidebar('phototitle-3');?>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 16rem;">
                    <?php dynamic_sidebar('photoimg-4');?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <!-- <h5 class="card-title">Card title</h5> -->
                        <?php dynamic_sidebar('phototitle-4');?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Photo Part End -->
    <!-- News Part Start -->
    <section class="container news mb-5 mt-5">
        <div class="row">
            <div class="col-sm-5">
                <?php echo get_template_directory_uri(). '/assets/images/gallery/line.png' ; ?>
            </div>
            <div class="col-sm-2">
                <h4>NEWS & EVENTS</h4>
                <p>click here to view all</p>
            </div>
            <div class="col-sm-5">
            </div>
        </div>
        <div class="row">
        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
  <div class="carousel-inner">

    <?php 
        $qry_2 = new WP_Query([
            'post_type' => 'post',
            'category_name' => 'News',
        ]);
        $x = 0;
            while($qry_2-> have_posts()){$qry_2->the_post();
        $x++;
    ?>
    <div class="carousel-item <?= ($x==1) ? 'active' : ''?>">
        <?php the_title();?>
    </div>
    <?php }?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
        </div>
    </section>
    <!-- News Part End -->
    section.
    <?php wp_footer()?>
</body>
</html>

