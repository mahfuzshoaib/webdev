<?php
wp_enqueue_style('style-sheet', get_stylesheet_uri());
wp_enqueue_style('bootstrap-style', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
wp_enqueue_script('bootstrap-script', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js' , array(), '1.0.0', true);



add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo');
add_theme_support( 'post-thumbnails' );
add_theme_support( 'custom-background' );

register_sidebar([
    'name' => 'Logo Right',
    'id' => 'logo_right',
    'before_widget' => '',
    'after_widget' => ''
]);
register_nav_menus(array(
    'TM' => 'primary',
));
register_sidebar([
    'name' => 'Hero Title',
    'id' => 'h_title',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Hero Card Image-1',
    'id' => 'card_img_1',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Hero Card Info-1',
    'id' => 'card_info_1',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Hero Card Image-2',
    'id' => 'card_img_2',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Hero Card Info-2',
    'id' => 'card_info_2',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Hero Card Image-3',
    'id' => 'card_img_3',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Hero Card Info-3',
    'id' => 'card_info_3',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Image Gallery-1',
    'id' => 'photoimg-1',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Image Title-1',
    'id' => 'phototitle-1',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Image Gallery-2',
    'id' => 'photoimg-2',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Image Title-2',
    'id' => 'phototitle-2',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Image Gallery-3',
    'id' => 'photoimg-3',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Image Title-3',
    'id' => 'phototitle-3',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Image Gallery-4',
    'id' => 'photoimg-4',
    'before_widget' => '',
    'after_widget' => '',
]);
register_sidebar([
    'name' => 'Image Title-4',
    'id' => 'phototitle-4',
    'before_widget' => '',
    'after_widget' => '',
]);
?>
