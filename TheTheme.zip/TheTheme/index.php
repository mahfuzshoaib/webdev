<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh</title>
    <?php wp_head(); ?>
</head>
<body>
    <!-- top bar start -->
    <header class="cont">
        <div class="row topbar">
            <div class="col-lg-6">
                <p>বাংলাদেশ জাতীয় তথ্য বাতায়ন</p>
            </div>
            <div class="col-lg-6 d-flex justify-content-end">
                <p>৭ অগ্রহায়ণ, ১৪২৯</p>
                <a href="#">English</a>
            </div>
        </div>
    </header>
    <!-- top bar end -->
    <!-- Logo part start -->
    <section class="cont logo">
        <div class="row">
            <div class="col-lg-5 logo_left">
                <a href="#">
                    <?php the_custom_logo();?>
                    
                </a>
            </div>
            <div class="col-lg-5 search">
                <input type="text" class="input" placeholder="খুঁজুন ">
                <input type="submit" class="button" value="অনুসন্ধান">
            </div>
            <div class="col-lg-2 logo_right">
                <div class="logo1 d-block">
                    <img src="./Assets/images/header/a2i-logo-footer.png" alt="">
                </div>
                <div class="logo2 d-block">
                    <p>সাথে থাকুন:</p>
                    <a href="#"><img src="./Assets/images/header/facebook-icon.png" alt=""></a>
                    <a href="#"><img src="./Assets/images/header/twitter-blue-icon.png" alt=""></a>
                    <a href="#"><img src="./Assets/images/header/youtube-icon.png" alt=""></a>
                    <a href="#"><img src="./Assets/images/header/gplus-icon.png" alt=""></a>
                </div>
            </div>
        </div>
    </section>
    <!-- Logo part end -->
    <!-- Menu part start -->
    <section class="cont">
        <div class="row">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                  <?php
                  wp_nav_menu([
                    'menu_location'=>'TM',
                    'menu_class'=>'navbar-nav'
                  ]);
                  ?>
                  <!-- <ul class="navbar-nav">
                    <li class="nav-item">
                      <a class="nav-link" href="#">হোম</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">বাংলাদেশ সম্পর্কিত</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">ই-সেবাসমূহ</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">সেবাখাত</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">ব্যবসা-বাণিজ্য</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"> বৈদেশিক বিনিয়োগ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">আইন-বিধি</a>
                    </li>
                  </ul> -->
                </div>
              </nav>
        </div>
    </section>
    <!-- Menu part end -->
    <!-- Hero part start -->
    <section class="cont hero">
        <div class="row">
            <div class="col-lg-8 hero_left">
                <div class="banner">
                    <a href="#"><img src="./Assets/images/slider/padmabanner.jpg" class="w-100 d-block" alt=""></a>
                </div>
                <!-- Slider part start -->
                <div class="slider">
                    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
                        <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="./Assets/images/slider/myGov Static2(1) (1).jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="./Assets/images/slider/banner-renew-your-passport.png" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="./Assets/images/slider/corona_banner.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="./Assets/images/slider/4-02.jpg" class="d-block w-100" alt="...">
                        </div>
                        </div>
                    </div>
                </div>
                <!-- Slider part end -->
                <!-- Tab part start -->
                <div class="tab">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">মোবাইল সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">দপ্তর ভিত্তিক সেবা</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                            <div class="row">
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/agriculture.png" alt=""></a>
                                    <p><a href="#">কৃষি</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/call_center.png" alt=""></a>
                                    <p><a href="#">কল সেন্টার</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/agriculture.png" alt=""></a>
                                    <p><a href="#">মৎস্য ও প্রাণী</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/helpdesk.png" alt=""></a>
                                    <p><a href="#">মোবাইল সেবা</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/mobile_service.png" alt=""></a>
                                    <p><a href="#">হেল্পডেস্ক</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/mobile_service.png" alt=""></a>
                                    <p><a href="#">হেল্পডেস্ক</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                            <div class="row">
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/agriculture.png" alt=""></a>
                                    <p><a href="#">কৃষি</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/call_center.png" alt=""></a>
                                    <p><a href="#">কল সেন্টার</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/agriculture.png" alt=""></a>
                                    <p><a href="#">মৎস্য ও প্রাণী</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/helpdesk.png" alt=""></a>
                                    <p><a href="#">মোবাইল সেবা</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/mobile_service.png" alt=""></a>
                                    <p><a href="#">হেল্পডেস্ক</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/mobile_service.png" alt=""></a>
                                    <p><a href="#">হেল্পডেস্ক</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
                            <div class="row">
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/agriculture.png" alt=""></a>
                                    <p><a href="#">কৃষি</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/call_center.png" alt=""></a>
                                    <p><a href="#">কল সেন্টার</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/agriculture.png" alt=""></a>
                                    <p><a href="#">মৎস্য ও প্রাণী</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/helpdesk.png" alt=""></a>
                                    <p><a href="#">মোবাইল সেবা</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/mobile_service.png" alt=""></a>
                                    <p><a href="#">হেল্পডেস্ক</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/mobile_service.png" alt=""></a>
                                    <p><a href="#">হেল্পডেস্ক</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">
                            <div class="row">
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/agriculture.png" alt=""></a>
                                    <p><a href="#">কৃষি</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/call_center.png" alt=""></a>
                                    <p><a href="#">কল সেন্টার</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/agriculture.png" alt=""></a>
                                    <p><a href="#">মৎস্য ও প্রাণী</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/helpdesk.png" alt=""></a>
                                    <p><a href="#">মোবাইল সেবা</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/mobile_service.png" alt=""></a>
                                    <p><a href="#">হেল্পডেস্ক</a></p>
                                </div>
                                <div class="col-lg-2 d-block">
                                    <a href="#"><img src="./Assets/images/tab/mobile_service.png" alt=""></a>
                                    <p><a href="#">হেল্পডেস্ক</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Tab part end -->
                <!-- Notice part start -->
                <div class="notice">
                    <h4 class="notice_head">উদ্যোগ</h4>
                    <ul>
                        <li><a href="#"> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a> <i>(১৩-০৬-২০১৬)</i></li>
                        <li><a href="#"> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a> <i>(১৩-০৬-২০১৬)</i></li>
                        <li><a href="#"> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a> <i>(১৩-০৬-২০১৬)</i></li>
                        <li><a href="#"> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a> <i>(১৩-০৬-২০১৬)</i></li>
                        <li><a href="#"> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a> <i>(১৩-০৬-২০১৬)</i></li>
                    </ul>
                    <button class="btn_align">সকল</button>
                </div>
                <!-- Notice part end -->
            </div>
            <div class="col-lg-4 hero_right">
                <div class="sidebar">
                    <a href="#"><img src="./Assets/images/sidebar/Bangladesh-Directory.jpg" class="d-block w-100" alt=""></a>
                    <a href="#"><img src="./Assets/images/sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100" alt=""></a>
                    <a href="#"><img src="./Assets/images/sidebar/dengu.jpg" class="d-block w-100" alt=""></a>
                    <a href="#"><img src="./Assets/images/sidebar/discount_bn.jpg" class="d-block w-100" alt=""></a>
                    <a href="#"><img src="./Assets/images/sidebar/Jonotar-Sorkar-banner-Bangl (1).jpg" class="d-block w-100" alt=""></a>
                    <h4>সকল বাতায়ন</h4>
                    <select name="" id="">
                        <option value="">ওয়েবসাইট বাছাই করুন</option>
                        <option value="">মন্ত্রণালয়</option>
                        <option value="">অধিদপ্তর </option>
                        <option value="">ঢাকা বিভাগ </option>
                        <option value="">চট্টগ্রাম বিভাগ </option>
                        <option value="">রাজশাহী বিভাগ </option>
                        <option value="">খুলনা বিভাগ </option>
                        <option value="">বরিশাল বিভাগ </option>
                    </select>
                    <input type="submit" class="button" value="চলুন">
                    <div class="mujib">
                        <h5>মুজিব১০০ আ্যাপ</h5>
                    </div>
                    <div class="sidebar_video">
                        <iframe width="315" height="200" src="https://www.youtube.com/embed/4Om3kZJL-qU" title="MUJIB100 APP | Speeches, Quotes, Books & More | Get Inspired Everyday" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero part end -->
    <!-- Footer part start  -->
    <footer class="cont">
        <div class="footer_top row">
            <img src="./Assets/images/footer/footer_top_bg.png" alt="">
        </div>
        <div class="footer_bottom row">
            <div class="col-lg-8">
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                      <ul class="navbar-nav">
                        <li class="nav-item">
                          <a class="nav-link" href="#">হোম</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#">বাংলাদেশ সম্পর্কিত</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#">ই-সেবাসমূহ</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#">সেবাখাত</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">ব্যবসা-বাণিজ্য</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"> বৈদেশিক বিনিয়োগ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">আইন-বিধি</a>
                        </li>
                      </ul>
                    </div>
                  </nav>
                  <p>সাইটটি শেষ হাল-নাগাদ করা হয়েছে: ২০২২-১০-৩০ ০৮:৩৫:০১</p>
            </div>
            <div class="col-lg-4">
                <p>পরিকল্পনা ও বাস্তবায়নে: এটুআই, মন্ত্রিপরিষদ বিভাগ, বিসিসি, বেসিস, ডিওআইসিটি</p>
                <span class="d-block">কারিগরি সহায়তায়:</span>
                <img src="./Assets/images/footer/np-logo-set.png" alt="" class="d-block">
            </div>
        </div>
    </footer>
    <!-- Footer part end -->
    <?php wp_footer()?>
    <!-- <script src="./Assets/js/bootstrap.bundle.min.js"></script> -->
</body>
</html>