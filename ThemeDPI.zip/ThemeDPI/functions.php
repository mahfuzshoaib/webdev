<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
?>