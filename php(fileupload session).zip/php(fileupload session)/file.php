<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        echo readfile("demo.txt");
        $info_file = "info.txt";
        $info = fopen($info_file, "r") or die("Unable to open file");
        echo fread($info, filesize($info_file));
        fclose($info);

        $info = fopen("info.txt", "a")
    ?>
</body>
</html>