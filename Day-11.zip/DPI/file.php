<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    $num1 = 294;
    $num2 = 9;
    $result = $num1 * $num2;
    ?>
    <div class="one">
        <p>This is the first <p>PHP</p> project</p>
    </div>
    <div class="sidebar">
        <h1>DPI</h1>
    </div>
    <div class="tree">
        <?php
        echo 'The multiplication of these numbers are = ' . $result . '<br>';
        if($num1 === $num2){
            echo 'True<br>';
        }
        else{
            echo'False<br>';
        }
        var_dump ($num2);
        ?>
        <?php
            echo'<br>';
            $t = date("H");
            if ($t < "20") {
            echo "Have a good day!";
            }
            else{
                echo"Good night";
            }
            echo"<br>Let's teach you some numbers: <br>";
            $i = 1; 
            while($i < 6){
                echo $i . "<br>";
                $i++;
            }
            $i = 5;
            for($r=1; $r<=10; $r++){
                echo $i ."X" . $r . "=" . $i*$r;
                echo "<br>";
            }
        ?>
    </div>
</body>
</html>