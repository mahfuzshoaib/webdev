    <!-- Footer part start -->
    <footer class="container-fluid bg-dark text-white-50">
        <div class="container">
            <div class="footer_t row pt-5">
                <div class="col-lg-6">
                    <h5>CONTACT US</h5>
                    <?php dynamic_sidebar('f_contact')?>
                </div>
                <div class="col-lg-6 f_links">
                        <h5>IMPORTANT LINKS</h5>
                        <?php dynamic_sidebar('f_links')?>
                </div>
            </div>
            <div class="footer_bottom">

            </div>
        </div>
        </div>
    </footer>
    <!-- Footer part end -->
    <?php wp_footer()?>
</body>
</html>