/*
    * Template Name: home
*/

<?php get_header()?>
    <!-- Hero part start -->
    <section class="container hero">
        <div class="row hero_title"> <?php dynamic_sidebar('h_title');?> </div>
        <div class="row hero_card">
            <div class="col-sm-4">
                <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('card_img_1');?>
                        <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <?php dynamic_sidebar('card_info_1');?>
                        <!-- <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> 
                        <a href="#" class="btn btn-primary">Go somewhere</a> -->
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('card_img_2');?>
                        <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <?php dynamic_sidebar('card_info_2');?>
                        <!-- <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> 
                        <a href="#" class="btn btn-primary">Go somewhere</a> -->
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('card_img_3');?>
                        <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <?php dynamic_sidebar('card_info_3');?>
                        <!-- <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> 
                        <a href="#" class="btn btn-primary">Go somewhere</a> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero part end -->
    <!-- Photo Part Start -->
    <section class="container photo text-center mt-5 mb-5">
        <div class="row">
            <div class="col-sm-5">
                <?php get_template_directory_uri(). '/assets/images/gallery/sb.png' ; ?>
            </div>
            <div class="col-sm-2">
                <h4>Recent Photos</h4>
                <p>Some Latest Project Pictures</p>
            </div>
            <div class="col-sm-5">
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="card" style="width: 16rem;">
                    <?php dynamic_sidebar('photoimg-1');?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <!-- <h5 class="card-title">Card title</h5> -->
                        <?php dynamic_sidebar('phototitle-1');?>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 16rem;">
                    <?php dynamic_sidebar('photoimg-2');?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <!-- <h5 class="card-title">Card title</h5> -->
                        <?php dynamic_sidebar('phototitle-2');?>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 16rem;">
                    <?php dynamic_sidebar('photoimg-3');?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <!-- <h5 class="card-title">Card title</h5> -->
                        <?php dynamic_sidebar('phototitle-3');?>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 16rem;">
                    <?php dynamic_sidebar('photoimg-4');?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    <div class="card-body">
                        <!-- <h5 class="card-title">Card title</h5> -->
                        <?php dynamic_sidebar('phototitle-4');?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Photo Part End -->
    <!-- News Part Start -->
    <section class="container news mb-5 mt-5">
        <div class="row">
            <div class="col-sm-5">
                <!-- <?php echo get_template_directory_uri(). '/assets/images/gallery/line.png' ; ?> -->
            </div>
            <div class="col-sm-2">
                <h4>NEWS & EVENTS</h4>
                <p>click here to view all</p>
            </div>
            <div class="col-sm-5">
            </div>
        </div>
        <div class="row">
        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
  <div class="carousel-inner">

    
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
        </div>
    </section>
    <!-- News Part End -->
<?php get_footer();?>