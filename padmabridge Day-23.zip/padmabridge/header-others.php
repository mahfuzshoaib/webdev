<!DOCTYPE html>
<html <?php language_attributes();?>>
<head>
    <meta charset="<?php bloginfo( 'charset' )?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head();?>
</head>
<body>
    <!-- Header part start -->
    <!-- Header part end -->
    <!-- Logo part start -->
    <section class="container-fluid logo">
        <div class="row">
            <div class="col-sm-6 logo_left"><?php the_custom_logo();?></div>
            <div class="col-sm-6 logo_right text-end"><?php dynamic_sidebar( 'logo_right' ); ?></div>
        </div>
    </section>
    <!-- Logo part end -->
    <!-- Menu part start -->
    <section class="container-fluid menu_tp mt-0">
        <div class="row">
            <nav class="navbar navbar-expand-lg bg-light">
                <div class="container">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'TM',
                            'menu_class' => 'navbar-nav menu_item'
                        ));
                        ?>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                    </ul>
                    </div>
                </div>
            </nav>
        </div>
    </section>
    <!-- <section class="container-fluid">
    </section> -->
    <!-- Menu part end -->
    <section class="container search">
        <div class="row">
            <div class="col-sm-8"></div>
            <div class="col-sm-4">
                <form action="">
                    <input type="text" <?php echo get_search_query();?> name="s">
                    <button>Search</button>
                </form>
            </div>
        </div>
    </section>